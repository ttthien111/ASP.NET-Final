﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ASPCore_Final.Models
{
    public class ChangePassword
    {
        public string MatKhauMoi { set; get; }
        public string XacNhanMatKhauMoi { set; get; }
    }
}
